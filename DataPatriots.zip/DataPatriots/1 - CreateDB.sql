/*
DROP TRIGGER MemberPointsCalculation

DROP PROCEDURE OrderAmountCalculation
DROP PROCEDURE InvoiceCalculation
DROP PROCEDURE Top_Employee
DROP PROCEDURE Most_Least_Product_Sale
DROP PROCEDURE Top_Customer

DROP FUNCTION Employee_SSN

DROP VIEW Membership_Customer
DROP VIEW Order_Type

DROP INDEX OP_EMPLOYEE_ID ON [ORDER]
DROP INDEX OP_ORDER_ID ON ORDER_PRODUCT

DROP TABLE INVENTORY
DROP TABLE SUPPLIER_PRODUCT
DROP TABLE WAREHOUSE
DROP TABLE SUPPLIER
DROP TABLE ORDER_PRODUCT
DROP TABLE PRODUCT
DROP TABLE INVOICE_HISTORY
DROP TABLE MEMBERSHIP
DROP TABLE [ORDER]
DROP TABLE CUSTOMER
DROP TABLE DEPARTMENT_MAPPING
DROP TABLE JOB_MAPPING
DROP TABLE PAYROLL_MAPPING
DROP TABLE DEPARTMENT
DROP TABLE JOB
DROP TABLE PAYROLL
DROP TABLE EMPLOYEE

DROP SYMMETRIC KEY EmpSSN_SM;
DROP CERTIFICATE EmpSSN;
DROP MASTER KEY;*/

-- Database Creation
CREATE DATABASE DataPatriots;
USE DataPatriots;
GO

-- Table EMPLOYEE
CREATE TABLE EMPLOYEE
(
	Employee_ID INT NOT NULL,
	Employee_SSN VARBINARY(400) NOT NULL,
	Employee_First_Name VARCHAR(20) NOT NULL,
	Employee_Last_Name VARCHAR(20) NULL,
	Employee_Middle_Name VARCHAR(20) NULL,
	Employee_DOB DATE NOT NULL,
	Employee_Address_Line1 VARCHAR(30) NOT NULL,
	Employee_Address_Line2 VARCHAR(30) NULL,
	Employee_Address_City VARCHAR(22) NOT NULL,
	Employee_Address_State VARCHAR(2) NOT NULL,
	Employee_Address_Zip INT NOT NULL,
	Employee_Phone_No NUMERIC(10) NOT NULL CONSTRAINT EMPLOYEE_PHONE_CHK CHECK (LEN(Employee_Phone_No) = 10),
	Employee_Type CHAR(10) NOT NULL CONSTRAINT EMPLOYEE_TYPE_CHK CHECK (Employee_Type IN ('Contractor', 'Full-Time', 'Part-Time')),
	Employee_Status CHAR(10) NOT NULL,
	Employee_Manager_ID INT NULL,
	CONSTRAINT PK_EMPLOYEE PRIMARY KEY (Employee_ID),
	CONSTRAINT FK_EMPLOYEE FOREIGN KEY (Employee_ID) REFERENCES EMPLOYEE(Employee_ID)
)

--Table PAYROLL
CREATE TABLE PAYROLL
(
	Payroll_ID INT NOT NULL,
	Payroll_Name VARCHAR(35) NOT NULL,
	Payroll_Type CHAR(10) NOT NULL CONSTRAINT PAYROLL_TYPE_CHK CHECK (Payroll_Type IN ('Hourly', 'Weekly', 'Monthly')),
	Payroll_Is_Active BIT NOT NULL,
	CONSTRAINT PK_PAYROLL PRIMARY KEY (Payroll_ID)
)

-- Table JOB
CREATE TABLE JOB
(
	Job_ID INT NOT NULL,
	Job_Name VARCHAR(15) NOT NULL,
	Job_Is_Active BIT NOT NULL,
	CONSTRAINT PK_JOB PRIMARY KEY (Job_ID)
)

-- Table DEPARTMENT
CREATE TABLE DEPARTMENT
(
	Department_ID INT NOT NULL,
	Department_Name VARCHAR(30) NOT NULL,
	Department_Is_Active BIT NOT NULL,
	CONSTRAINT PK_DEPARTMENT PRIMARY KEY (Department_ID)
)

-- Table PAYROLL_MAPPING
CREATE TABLE PAYROLL_MAPPING
(
	Payroll_ID INT NOT NULL,
	Employee_ID INT NOT NULL,
	Payroll_Rate FLOAT NOT NULL,
	Payroll_Start_Date DATE NOT NULL,
	Payroll_End_Date DATE NULL,
	CONSTRAINT PK_PAYROLL_MAPPING PRIMARY KEY (Payroll_ID,Employee_ID),
	CONSTRAINT FK_PAYROLL_MAPPING_1 FOREIGN KEY (Payroll_ID) REFERENCES PAYROLL(Payroll_ID),
	CONSTRAINT FK_PAYROLL_MAPPING_2 FOREIGN KEY (Employee_ID) REFERENCES EMPLOYEE(Employee_ID)
)

-- Table JOB_MAPPING
CREATE TABLE JOB_MAPPING
(
	Job_ID INT NOT NULL,
	Employee_ID INT NOT NULL,
	Job_Is_Active BIT NOT NULL,
	Job_Start_Date DATE NOT NULL,
	Job_End_Date DATE NULL,
	CONSTRAINT PK_JOB_MAPPING PRIMARY KEY (Job_ID,Employee_ID),
	CONSTRAINT FK_JOB_MAPPING_1 FOREIGN KEY (Job_ID) REFERENCES JOB(Job_ID),
	CONSTRAINT FK_JOB_MAPPING_2 FOREIGN KEY (Employee_ID) REFERENCES EMPLOYEE(Employee_ID)
)

-- Table DEPARTMENT_MAPPING
CREATE TABLE DEPARTMENT_MAPPING
(
	Department_ID INT NOT NULL,
	Employee_ID INT NOT NULL,
	Department_Start_Date DATE NOT NULL,
	Department_End_Date DATE NULL
	CONSTRAINT PK_DEPARTMENT_MAPPING PRIMARY KEY (Department_ID,Employee_ID),
	CONSTRAINT FK_DEPARTMENT_MAPPING_1 FOREIGN KEY (Department_ID) REFERENCES DEPARTMENT(Department_ID),
	CONSTRAINT FK_DEPARTMENT_MAPPING_2 FOREIGN KEY (Employee_ID) REFERENCES EMPLOYEE(Employee_ID)
)

-- Table CUSTOMER
CREATE TABLE CUSTOMER
(
	Customer_ID INT NOT NULL,
	Customer_First_Name VARCHAR(15) NOT NULL,
	Customer_Middle_Name VARCHAR(10) NULL,
	Customer_Last_Name VARCHAR(15) NULL,
	Customer_DOB DATE NULL,
	Customer_Address_Line1 VARCHAR(40) NULL,
	Customer_Address_Line2 VARCHAR(20) NULL,
	Customer_Address_City CHAR(22) NULL,
	Customer_Address_State CHAR(15) NULL,
	Customer_Address_Zip VARCHAR(15) NULL,
	Customer_PhoneNo NUMERIC(10) NULL CONSTRAINT CUSTOMER_PHONE_CHK CHECK (LEN(Customer_PhoneNo) = 10),
	CONSTRAINT PK_CUSTOMER PRIMARY KEY (Customer_ID)
)

-- Table MEMBERSHIP
CREATE TABLE MEMBERSHIP
(
	Membership_ID INT NOT NULL,
	Membership_Points INT NOT NULL,
	Membership_Validity_Date DATE NOT NULL,
	Customer_ID INT NOT NULL,
	CONSTRAINT PK_MEMBERSHIP PRIMARY KEY (Membership_ID),
	CONSTRAINT FK_MEMBERSHIP FOREIGN KEY (Customer_ID) REFERENCES CUSTOMER(Customer_ID)
)

-- Table [ORDER]
CREATE TABLE [ORDER]
(
	Order_ID INT NOT NULL,
	Customer_ID INT NOT NULL,
	Employee_ID INT NOT NULL,
	Order_Amount FLOAT NOT NULL,
	Order_Type VARCHAR(10) NULL,
	CONSTRAINT PK_ORDER PRIMARY KEY (Order_ID),
	CONSTRAINT FK_ORDER_1 FOREIGN KEY (Customer_ID) REFERENCES CUSTOMER(Customer_ID),
	CONSTRAINT FK_ORDER_2 FOREIGN KEY (Employee_ID) REFERENCES EMPLOYEE(Employee_ID)
)

-- Table INVOICE_HISTORY
CREATE TABLE INVOICE_HISTORY
(
	Invoice_ID INT NOT NULL,
	Order_ID INT NOT NULL,
	Invoice_Amount FLOAT NOT NULL,
	Invoice_Tax FLOAT NOT NULL,
	Invoice_Discount FLOAT NULL,
	CONSTRAINT PK_INVOICE_HISTORY PRIMARY KEY (Invoice_ID),
	CONSTRAINT FK_INVOICE_HISTORY FOREIGN KEY (Order_ID) REFERENCES [ORDER](Order_ID)
)

-- Table PRODUCT
CREATE TABLE PRODUCT
(
	Product_ID INT NOT NULL,
	Product_Name VARCHAR(60) NOT NULL,
	Product_Description VARCHAR(60) NULL,
	Product_Category CHAR(30) NOT NULL,
	Product_Brand VARCHAR(30) NULL,
	Product_Price FLOAT NOT NULL,
	CONSTRAINT PK_PRODUCT PRIMARY KEY (Product_ID)
)

-- Table ORDER_PRODUCT
CREATE TABLE ORDER_PRODUCT
(
	Order_ID INT NOT NULL,
	Product_ID INT NOT NULL,
	Order_Quantity INT NOT NULL,
	Order_Date DATE NOT NULL
	CONSTRAINT PK_ORDER_PRODUCT PRIMARY KEY (Order_ID,Product_ID),
	CONSTRAINT FK_ORDER_PRODUCT_1 FOREIGN KEY (Order_ID) REFERENCES [ORDER](Order_ID),
	CONSTRAINT FK_ORDER_PRODUCT_2 FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID)
	
)

-- Table SUPPLIER
CREATE TABLE SUPPLIER
(
	Supplier_ID INT NOT NULL,
	Supplier_Name VARCHAR(35) NOT NULL,
	Supplier_Location VARCHAR(35) NOT NULL,
	CONSTRAINT PK_SUPPLIER PRIMARY KEY (Supplier_ID)
)

-- Table SUPPLIER_PRODUCT
CREATE TABLE SUPPLIER_PRODUCT
(
	Supplier_ID INT NOT NULL,
	Product_ID INT NOT NULL,
	Supplier_Cost Money NOT NULL,
	CONSTRAINT PK_SUPPLIER_PRODUCT PRIMARY KEY (Supplier_ID,Product_ID),
	CONSTRAINT FK_SUPPLIER_PRODUCT_1 FOREIGN KEY (Supplier_ID) REFERENCES SUPPLIER(Supplier_ID),
	CONSTRAINT FK_SUPPLIER_PRODUCT_2 FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID)
)

-- Table WAREHOUSE
CREATE TABLE WAREHOUSE
(
	Warehouse_ID INT NOT NULL,
	Warehouse_Name VARCHAR(35) NOT NULL,
	Warehouse_Location VARCHAR(35) NOT NULL,
	CONSTRAINT PK_WAREHOUSE PRIMARY KEY (Warehouse_ID)
)

-- Table INVENTORY
CREATE TABLE INVENTORY
(
	Warehouse_ID INT NOT NULL,
	Product_ID INT NOT NULL,
	Inventory_Quantity INT NULL,
	CONSTRAINT PK_INVENTORY PRIMARY KEY (Warehouse_ID,Product_ID),
	CONSTRAINT FK_INVENTORY_1 FOREIGN KEY (Warehouse_ID) REFERENCES WAREHOUSE(Warehouse_ID),
	CONSTRAINT FK_INVENTORY_2 FOREIGN KEY (Product_ID) REFERENCES PRODUCT(Product_ID)
)

CREATE MASTER KEY
ENCRYPTION BY PASSWORD = 'ProjDB123';

CREATE CERTIFICATE EmpSSN
   WITH SUBJECT = 'Employee SSN';  
GO

CREATE SYMMETRIC KEY EmpSSN_SM
    WITH ALGORITHM = AES_256
    ENCRYPTION BY CERTIFICATE EmpSSN;
GO

-- Employee ID non-clustered index
CREATE NONCLUSTERED INDEX OP_EMPLOYEE_ID
ON [ORDER](Employee_ID);

-- Order ID non-clustered index
CREATE NONCLUSTERED INDEX OP_ORDER_ID
ON [ORDER_PRODUCT](Order_ID);
GO

-- View for each Customer and their respective Membership points
CREATE VIEW dbo.Membership_Customer AS
SELECT  C.Customer_First_Name,
		C.Customer_Middle_Name,
		C.Customer_Last_Name,
		M.Membership_Points
  FROM  CUSTOMER C,
		MEMBERSHIP M
 WHERE  C.Customer_ID = M.Customer_ID
GO

-- View for to see the Counts of Online versus In-store orders
CREATE VIEW dbo.Order_Type AS
SELECT  Order_Type,
		COUNT(Order_Type) AS Total_Orders
  FROM  [ORDER]
GROUP BY Order_Type
GO

--Trigger for calculation of the membership points
CREATE TRIGGER MemberPointsCalculation
ON [ORDER]
FOR UPDATE
AS 
BEGIN
	UPDATE MEMBERSHIP SET Membership_Points = Total_Amount*0.1
	FROM  (
			SELECT  Customer_ID,
					SUM(Order_Amount) Total_Amount
			  FROM  inserted
			GROUP BY Customer_ID
		  ) Query
	WHERE MEMBERSHIP.Customer_ID = Query.Customer_ID
END
GO

------- Procedure 1 -------
CREATE PROCEDURE OrderAmountCalculation
AS
BEGIN
UPDATE [ORDER] SET Order_Amount = Query.Amount
FROM  (
		SELECT  O.Order_ID OID, SUM(O_P.Order_Quantity*P.Product_Price) Amount
		  FROM  PRODUCT P,
				ORDER_PRODUCT O_P,
				[ORDER] O
		 WHERE  P.Product_ID = O_P.Product_ID
		   AND  O.Order_ID = O_P.Order_ID
		GROUP BY O.Order_ID
	  ) AS Query
WHERE Order_ID = Query.OID
END
GO


------- Procedure 2 -------
CREATE PROCEDURE InvoiceCalculation
AS
BEGIN
UPDATE INVOICE_HISTORY SET	Invoice_Tax = Query.Tax,
							Invoice_Amount = (Query.Tax + Amount - ((Invoice_Discount*Amount)/100))
FROM  (
		SELECT  Order_ID OID,
				Order_Amount Amount,
				Order_Amount*0.18 Tax
		  FROM  [ORDER] O
	  ) AS Query
WHERE Order_ID = Query.OID
END
GO

------- Procedure 3 -------
CREATE PROCEDURE Top_Employee
AS
BEGIN
SELECT  Query.*
  FROM  (
		SELECT  Employee_ID,
				Count(*) AS Order_Count
		  FROM  [ORDER]
		GROUP BY [ORDER].Employee_ID
		) Query,
		(
		SELECT  MAX(SubQuery.order_count) AS Highest_Count
		  FROM  (
				SELECT  Employee_ID,
						Count(*) AS Order_Count
				FROM [ORDER]
				GROUP BY [ORDER].Employee_ID
				) SubQuery
		) CompQuery
 WHERE  Query.Order_Count = CompQuery.Highest_Count;
END
GO


------- Procedure 4 -------
CREATE PROCEDURE MOST_LEAST_PRODUCT_SALE
AS
BEGIN
        SELECT 	TOP 5 PRODUCT_ID,
				SUM(ORDER_QUANTITY) AS MOST_PRODUCT_SALE
          FROM  ORDER_PRODUCT
        GROUP BY Product_ID
        ORDER BY MOST_PRODUCT_SALE DESC

        SELECT  TOP 5 PRODUCT_ID,
				SUM(ORDER_QUANTITY) AS LEAST_PRODUCT_SALE
          FROM  ORDER_PRODUCT
        GROUP BY Product_ID
        ORDER BY LEAST_PRODUCT_SALE ASC
END
GO


------- Procedure 5 -------
CREATE PROCEDURE Top_Customer @Cust_ID INT
AS
BEGIN
    SELECT  Query.*
      FROM (
			SELECT  Customer_id,
					Count(*) AS Order_Count
              FROM  [ORDER]
             WHERE  Customer_ID = @Cust_ID
            GROUP BY [ORDER].Customer_id
			) Query,
			(
			SELECT  MAX(SubQuery.order_count) AS highest_count
			  FROM  (
					SELECT  Customer_id,
							COUNT(*) AS Order_Count
					  FROM  [ORDER]
					 WHERE  Customer_ID = @Cust_ID
					GROUP BY [ORDER].Customer_id
					) SubQuery
			) CompQuery
    WHERE Query.order_count = CompQuery.highest_count;
END
GO

CREATE FUNCTION Employee_SSN (@emp_no INT)
RETURNS VARCHAR(12)
AS BEGIN
	DECLARE @SSN VARCHAR(12)
	SET @SSN =
	(
		SELECT  CONVERT(VARCHAR,DecryptByKey(Employee_SSN))
		  FROM  EMPLOYEE
		 WHERE  Employee_ID = @emp_no
	);

RETURN @SSN
END
GO
