-- Order and Invoice Amount Calculations
EXEC OrderAmountCalculation;
EXEC InvoiceCalculation;

SELECT * FROM INVOICE_HISTORY;
SELECT * FROM [ORDER];
SELECT * FROM MEMBERSHIP;

-- Procedures to View stats
EXEC Top_Employee
EXEC Most_Least_Product_Sale
EXEC Top_Customer 105014

-- Viewing the created views
SELECT * FROM Order_Type
SELECT * FROM Membership_Customer